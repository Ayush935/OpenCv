
#include <opencv2/opencv.hpp>
#include <iostream>
 
using namespace cv;
using namespace std;
 
int main(int argc, char** argv) {
    // Check if image path is provided
    if (argc != 2) {
        cout << "Usage: " << argv[0] << " <Image_Path>" << endl;
        return -1;
    }
    Mat src = imread(argv[1], IMREAD_GRAYSCALE);
    if (src.empty()) {
        cout << "Error: Could not open or find the image." << endl;
        return -1;
    }
 
   
    Mat edges;
    Canny(src, edges, 50, 200);
 
    vector<Vec2f> lines;
    HoughLines(edges, lines, 1, CV_PI/180, 150);
 

    Mat dst;
    cvtColor(edges, dst, COLOR_GRAY2BGR);
    for (size_t i = 0; i < lines.size(); i++) {
        float rho = lines[i][0], theta = lines[i][1];
        Point pt1, pt2;
        double a = cos(theta), b = sin(theta);
        double x0 = a*rho, y0 = b*rho;
        pt1.x = cvRound(x0 + 1000*(-b));
        pt1.y = cvRound(y0 + 1000*(a));
        pt2.x = cvRound(x0 - 1000*(-b));
        pt2.y = cvRound(y0 - 1000*(a));
        line(dst, pt1, pt2, Scalar(0,0,255), 3, LINE_AA);
    }
 
    // Display the results
    imshow("Detected Lines", dst);
    waitKey(0);
    return 0;
}
