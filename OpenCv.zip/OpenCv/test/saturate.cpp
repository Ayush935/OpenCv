#include <iostream>
#include <opencv2/opencv.hpp>

/*
  Saturate--------------> Brightness and contrast adjustments
*/
int main()
{
    std::string path = "/home/kpit/opencv/samples/data/lena.jpg";
    cv::Mat img = cv::imread(path, cv::IMREAD_COLOR);
    //    cv::Mat convert_img;
    //    cv::cvtColor(img,convert_img,cv::COLOR_BGR2GRAY);
    //    cv::imshow("Dsiplay image",convert_img);
    //    std::cout<<"Number of channels "<<img.channels()<<std::endl;
    //    cv::waitKey(0);
    cv::Mat dest_image = cv::Mat::zeros(img.size(), img.type());
    // cv::Mat dest_image = img;
    //    for(int i=0;i<=img.rows;i++){
    //     for(int j=0;j<=img.cols;i++){
    //          dest_image = 10*img*10;

    //     }
    //    }
    std::cout<<"Enter Brightness "<<std::endl;
    float brightness;
    std::cin>>brightness;
    std::cout<<"Enter Contrast "<<std::endl;
    float contrast;
    std::cin>>contrast;
    for (int i = 0; i < img.rows; i++)
    {
        for (int j = 0; j < img.cols; j++)
        {
            for (int c = 0; c < img.channels(); c++)
            {
                dest_image.at<cv::Vec3b>(i, j)[c] =
                    cv::saturate_cast<uchar>(contrast * img.at<cv::Vec3b>(i, j)[c] + brightness);
            }
        }
    }

    cv::imshow("Display Dest image",dest_image);
    cv::waitKey(0);
    return 0;
}