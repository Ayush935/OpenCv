#include <iostream>
#include <opencv2/opencv.hpp>

using namespace cv;

int main() {
    Mat image = imread("/home/kpit/opencv/samples/data/fruits.jpg");
    imshow("Original image", image);

    // Flip the image vertically
    Mat flipped_image;
    flip(image, flipped_image, 0); // 0 for vertical flip, 1 for horizontal flip, -1 for both

    imshow("Flipped image", flipped_image);
    imwrite("flipped_image.jpg", flipped_image);

    waitKey(0);
    return 0;
}