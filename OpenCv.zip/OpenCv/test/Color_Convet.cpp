#include <iostream>
#include <opencv2/opencv.hpp>

/*
  COLOR_CONVERT
*/
int main(){
   std::string path = "/home/kpit/opencv/samples/data/lena.jpg";
   cv::Mat img = cv::imread(path,cv::IMREAD_COLOR);
   cv::Mat convert_img;
   cv::cvtColor(img,convert_img,cv::COLOR_BGR2GRAY);
   cv::imshow("Dsiplay image",convert_img);
   std::cout<<"Number of channels "<<img.channels()<<std::endl;
   cv::waitKey(0);
}