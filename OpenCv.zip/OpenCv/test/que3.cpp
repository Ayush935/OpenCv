// #include <opencv2/opencv.hpp>
// #include <iostream>

// using namespace cv;
// using namespace std;

// int main() {
//     // Read the image
//     Mat image = imread("/home/kpit/opencv/samples/data/opencv-logo.png", IMREAD_COLOR);

//     // Check if the image is loaded
//     if (image.empty()) {
//         cout << "Could not open or find the image" << endl;
//         return -1;
//     }

//     // Convert the image to grayscale
//     Mat gray;
//     cvtColor(image, gray, COLOR_BGR2GRAY);

//     // Convert the image back to BGR format
//     Mat image_bgr;
//     cvtColor(gray, image_bgr, COLOR_GRAY2BGR);

//     // Set the background to black
//     // image_bgr[:, :, 0] = 0;
//     // image_bgr[:, :, 1] = 0;
//     // image_bgr[:, :, 2] = 0;

//     string text = "Open CV";


//     int fontFace = FONT_HERSHEY_SIMPLEX;

//     double fontScale = 1;

  
//     Scalar fontColor(255, 255, 0);  // Yellow color

//     int thickness = 2;

//     Point org(10, 20);

//     putText(image_bgr, text, org, fontFace, fontScale, fontColor, thickness);

//     namedWindow("Image", 1);
//     imshow("Image", image_bgr);
//     waitKey(0);
//     destroyAllWindows();

//     return 0;
// }

// #include <opencv2/opencv.hpp>
// #include <iostream>
// #include <vector>
 
// using namespace std;
// using namespace cv;
 
// int main()
// {
//     Mat original = imread("/home/kpit/opencv/samples/data/opencv-logo.png",IMREAD_UNCHANGED);
 
//     Mat img(original.size(),CV_8UC3);
 
//     vector<Mat> channels;
//     split(original,channels);
 
//     for(int i=0;i<original.rows;i++)
//     {
//     for(int j=0;j<original.cols;j++)
//     {
//         float alpha=channels[3].at<uchar>(i,j)/255.0f;
//         img.at<Vec3b>(i,j)[0]=channels[0].at<uchar>(i,j)*alpha +(1-alpha)*0;
//         img.at<Vec3b>(i,j)[1]=channels[1].at<uchar>(i,j)*alpha +(1-alpha)*0;
//         img.at<Vec3b>(i,j)[2]=channels[2].at<uchar>(i,j)*alpha +(1-alpha)*0;
//     }
 
//     }
 
//     Mat imgo=img.clone();
 
//     int top=0.05*(img.rows);
//     int left=0.05*(img.cols);
//     int bottom=top;
//     int right=left;
 
//     copyMakeBorder(img,img,top,bottom,left,right,BORDER_CONSTANT,Scalar(0,0,0));
 
//     imshow("Original image ",imgo);
//     imshow("Bordered image ",img);
//     imwrite("219596.jpg",img);
 
//     waitKey(0);
 
 
//     return 0;
// }


#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>

using namespace std;
using namespace cv;

int main()
{
    Mat original = imread("/home/kpit/opencv/samples/data/opencv-logo.png", IMREAD_UNCHANGED);

    Mat img(original.size(), CV_8UC3);

    vector<Mat> channels;
    split(original, channels);

    for (int i = 0; i < original.rows; i++)
    {
        for (int j = 0; j < original.cols; j++)
        {
            float alpha = channels[3].at<uchar>(i, j) / 255.0f;
            img.at<Vec3b>(i, j)[0] = channels[0].at<uchar>(i, j) * alpha + (1 - alpha) * 0;
            img.at<Vec3b>(i, j)[1] = channels[1].at<uchar>(i, j) * alpha + (1 - alpha) * 0;
            img.at<Vec3b>(i, j)[2] = channels[2].at<uchar>(i, j) * alpha + (1 - alpha) * 0;
        }
    }

    Mat imgo = img.clone();

    int top = 0.05 * (img.rows);
    int left = 0.05 * (img.cols);
    int bottom = top;
    int right = left;

    copyMakeBorder(img, img, top, bottom, left, right, BORDER_CONSTANT, Scalar(0, 0, 0));

    putText(img, "OpenCV", Point(left + 10, img.rows - bottom - 80), FONT_HERSHEY_SIMPLEX, 5, Scalar(0, 255, 255), 16);

    imshow("Original image ", original);
    imshow("Bordered image ", img);
    imwrite("219363.jpg", img);

    waitKey(0);

    return 0;
}