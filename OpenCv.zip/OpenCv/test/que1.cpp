#include <opencv2/opencv.hpp>

int main() {

    cv::Mat image = cv::imread("/home/kpit/opencv/samples/data/cards.png");

    cv::Mat gray;
    cv::cvtColor(image, gray, cv::COLOR_BGR2GRAY);

    cv::Mat edges;
    cv::Canny(gray, edges, 100, 200);

    // cv::imshow("Canny Edges", edges);
    // cv::imwrite("219363_canny.jpg",edges);

      
    std::vector<std::vector<cv::Point>> contours;
    std::vector<cv::Vec4i> hierarchy;
    cv::findContours(edges, contours, hierarchy, cv::RETR_TREE, cv::CHAIN_APPROX_SIMPLE);
 
    
    cv::Mat contourOutput = image.clone();
    for (size_t idx = 0; idx < contours.size(); idx++) {
        cv::drawContours(contourOutput, contours, static_cast<int>(idx), cv::Scalar(255, 0, 0), 1);
    }

    std::vector<double> areas;
    for (const auto& contour : contours) {
        double area = cv::contourArea(contour);
        areas.push_back(area);
    }

    std::sort(areas.begin(), areas.end());

    double smallest_area = areas.front();
    std::cout << "Area of the smallest contour: " << smallest_area << std::endl;
 
    // cv::imshow("219363_contour.jpg", contourOutput);
    // cv::imwrite("219363_contour.jpg", contourOutput);
    // cv::waitKey(0);
    // cv::destroyAllWindows();


    double min_distance = std::numeric_limits<double>::max();
    cv::Point nearest_point;

    for (const auto& contour : contours) {
        double distance = cv::pointPolygonTest(contour, cv::Point(203, 263), true);
        if (std::abs(distance) < min_distance) {
            min_distance = std::abs(distance);
            nearest_point = cv::Point(203, 263);
        }
    }

    std::cout << "Distance of point (203, 263) from its nearest contour: " << min_distance << std::endl;

    return 0;
}


