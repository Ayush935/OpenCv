#include <opencv2/opencv.hpp>

int main() {
    // Read the image as gray-scale
    cv::Mat img = cv::imread("/home/kpit/opencv/samples/data/smarties.png", cv::IMREAD_COLOR);
    
    // Convert to gray-scale
    cv::Mat gray;
    cv::cvtColor(img, gray, cv::COLOR_BGR2GRAY);
    
    // Blur the image to reduce noise
    cv::Mat img_blur;
    cv::medianBlur(gray, img_blur, 5);
    
    // Create a vector for detected circles
    std::vector<cv::Vec3f> circles;
    
    // Apply Hough Transform
    cv::HoughCircles(img_blur, circles, cv::HOUGH_GRADIENT, 1, img.rows/64, 200, 10, 5, 30);
    
    // Draw detected circles
    for(size_t i=0; i<circles.size(); i++) {
        cv::Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
        int radius = cvRound(circles[i][2]);
        cv::circle(img, center, radius, cv::Scalar(255, 255, 255), 2, 8, 0);
    }
    
    // Display the result
    cv::imshow("detected circles", img);
    cv::waitKey(0);
    
    return 0;
}