#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

int main() {
    // Read the input image
    cv::Mat src = cv::imread("/home/kpit/opencv/samples/data/LinuxLogo.jpg", cv::IMREAD_COLOR);
    
    // Create a structuring element (kernel)
    int erosion_size = 5;
    cv::Mat element = cv::getStructuringElement(cv::MORPH_RECT,
                                               cv::Size(erosion_size + 1, erosion_size+1),
                                               cv::Point(erosion_size, erosion_size));
    
    // Apply erosion
    cv::Mat eroded;
    cv::erode(src, eroded, element, cv::Point(-1,-1), 1);

     // Apply dilation
    cv::Mat dilated;
    cv::dilate(src, dilated, element, cv::Point(-1,-1), 1);
    
    //Display the orignal image
    cv::imshow("Orignal Image", src);
    
    // Display the eroded image
    cv::imshow("Eroded Image", eroded);
    cv::imshow("Dilated Image", dilated);
    cv::waitKey(0);
    
    return 0;
}

/*
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace cv;
using namespace std;
 
int main(){
    // Mat image1 = imread("/home/kpit/Downloads/download.jpeg",IMREAD_COLOR);
    Mat image1 = imread("/home/kpit/opencv-4.x/samples/data/LinuxLogo.jpg",IMREAD_COLOR);
    Mat image2 = imread("/home/kpit/Downloads/imagee.jpeg",IMREAD_COLOR);
    Mat image(image1.rows, image1.cols, image1.type());
    // resize(image2,image2,image1.size());
 
    // add(image1,image2,image);
    // image = image1 | image2;
 
    // int decrease_factor = 50;
    // Mat resultant_image = image - decrease_factor;
    // imshow("Window Name", resultant_image);
    int kernel_size=4;
    Mat my_kernel = (Mat_<double>(kernel_size,kernel_size) << 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1) / ( kernel_size*kernel_size);
    
    // boxFilter(image1,image,-1,Size(3,3),Point(-1,-1),true,BORDER_DEFAULT);
    // imshow("ORIGINALBOX",image1);
    // imshow("NEWBOX",image);
    // blur(image1,image,Size(5,5),Point(-1,-1),BORDER_DEFAULT);
    // GaussianBlur(image1,image,Size(3,3),0,0,BORDER_DEFAULT);//sigmax, sigma y is the standard deviation among x and y values
    // imshow("ORIGINALGAUSS",image1);
    // medianBlur(image1,image,5);
    // imshow("MEDIANBLUR",image);
    // filter2D(image1,image,-1,my_kernel);
    // imshow("filter2d",image);
 
    Mat ans = cv::getStructuringElement(0,Size(4,4));
    cv::erode(image1,ans,my_kernel);
    imshow("erode",ans);
    cv::dilate(image1,ans,my_kernel);
    imshow("dilate",ans);
    waitKey(0);
}
*/
 
