#include <iostream>
#include <opencv2/opencv.hpp>

/*
  CROP AND SCALE
*/
int main(){
   std::string path = "/home/kpit/opencv/samples/data/lena.jpg";
   cv::Mat img = cv::imread(path,cv::IMREAD_COLOR);
//    cv::Mat convert_img;
//    cv::cvtColor(img,convert_img,cv::COLOR_BGR2GRAY);
//    cv::imshow("Dsiplay image",convert_img);
//    std::cout<<"Number of channels "<<img.channels()<<std::endl;
//    cv::waitKey(0);


  /*
     CROP
  */
//    cv::imshow("Dsiplay image",img);
//    cv::Rect r(10,10,100,100);
//    cv::Mat small_img = img(r);
//    cv::imshow("Cropped image",small_img);
//    cv::waitKey(0);


   /*
     SCALE   ------------ resize
   */
   cv::imshow("Dsiplay image",img);
   cv::Mat resized_img;
   cv::resize(img,resized_img,cv::Size(10,10),cv::INTER_LINEAR);
   cv::resize(img,resized_img,cv::Size(),2,2,cv::INTER_LINEAR);
   cv::imshow("Scaled IMage",resized_img);
   cv::waitKey(0);


}