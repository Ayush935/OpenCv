#include <iostream>
#include <opencv2/opencv.hpp>
using namespace cv;

int main(){
    /*
      READ, Display AND WRITE image , with colors representation
    */

    // std::cout<<CV_VERSION<<std::endl;
    // std::cout<<"Open CV installed"<<std::endl;
    // return 0;

    // cv::Mat img = cv::imread("/home/kpit/opencv/samples/data/lena.jpg",cv::IMREAD_COLOR);
    // cv::imshow("Display Image : ",img);
    // cv::waitKey(0);
    // return 0;
/*
    std::string path = "/home/kpit/opencv/samples/data/lena.jpg";
    Mat img = imread(path,IMREAD_COLOR );
    // Mat img = imread(path,IMREAD_REDUCED_COLOR_8 );
    // Mat img = imread(path,IMREAD_IGNORE_ORIENTATION  );
    // Mat img = imread(path,IMREAD_ANYCOLOR );
    // Mat img = imread(path,IMREAD_LOAD_GDAL  );
    // Mat img = imread(path,IMREAD_REDUCED_GRAYSCALE_2  );
    // Mat img = imread(path,IMREAD_REDUCED_COLOR_2  );
    // Mat img = imread(path,IMREAD_REDUCED_GRAYSCALE_4  );
    // Mat img = imread(path,IMREAD_REDUCED_COLOR_4   );
    // Mat img = imread("/home/kpit/opencv/samples/data/lena.jpg",IMREAD_REDUCED_GRAYSCALE_8 );
    imshow("Display Image : ",img);
    imwrite("Myimage.jpg",img);
    waitKey(0);
    return 0;
*/

    /*
      intensity of pixel
    */
    // std::string path = "/home/kpit/opencv/samples/data/lena.jpg";
    // Mat img = imread(path,IMREAD_GRAYSCALE);
    // imshow("Display Image : ",img);
    // unsigned int y=120, x=120;

    // int intensity = img.at<uchar>(y,x);
    // std::cout<<"Intensity: "<<intensity<<std::endl;
    // waitKey(0);
    // return 0;

    /*
      Display grayScale in binary form
    */
    /*
    std::string path = "/home/kpit/opencv/samples/data/lena.jpg";
    Mat img = imread(path,IMREAD_GRAYSCALE);
    
    int intensity;
    // unsigned int y=img.rows, x=img.cols;   rows and columns
    for(int i=0;i<=img.rows;i++){
        for(int j=0;j<=img.cols;j++){
            intensity = img.at<uchar>(i,j);
            if(intensity>127){
                img.at<uchar>(i,j)=255;
            }
            else{
                img.at<uchar>(i,j)=0;
            }
        }
    }
    imshow("Display Image : ",img);
    // std::cout<<"Intensity: "<<intensity<<std::endl;
    waitKey(0);
    return 0;
    */

    /*
      intensity of colored image
    */
    /*
    std::string path = "/home/kpit/opencv/samples/data/lena.jpg";
    Mat img = imread(path,IMREAD_COLOR);
    imshow("Display Image : ",img);
    unsigned int y=120, x=100;
    Vec3d intensity = img.at<Vec3b>(y,x);
    // unsigned int y=img.rows, x=img.cols;   rows and columns
    unsigned int blue = intensity.val[0];
    unsigned int green = intensity.val[1];
    unsigned int red = intensity.val[2];
    imshow("Display Image : ",img);
    std::cout<<"Intensity: "<<"blue: "<<blue<<" green: "<<green<<" red: "<<red<<std::endl;
    waitKey(0);
    return 0;
    */

   /*
     Split Channels and Merge Channels
   */
    
   //split
   std::string path = "/home/kpit/opencv/samples/data/lena.jpg";
   Mat img = imread(path,IMREAD_COLOR);
   Mat channel[3];
   cv::split(img,channel);
   Mat blue_channel=channel[0], green_channel= channel[1], red_channel= channel[2];
   imshow("Display Image1 : ",green_channel);
   imshow("Display Image2 : ",blue_channel);
   imshow("Display Image3 : ",red_channel);
   waitKey(1000);
//    return 0;
   
    //Merge
   Mat color_img_new;
   std::vector<cv::Mat>v {blue_channel,green_channel,red_channel};
   merge(v,color_img_new);
   imshow("Display Merge Image : ",color_img_new);
   waitKey(10000);
  

   
}