#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

int main() {
    // Create a black image
    Mat image = Mat::zeros(400, 400, CV_8UC3);

    // Draw a rectangle
    rectangle(image, Point(50, 50), Point(200, 200), Scalar(255, 0, 0), 2);

    // Draw a circle
    circle(image, Point(300, 100), 50, Scalar(0, 255, 0), -1);

    // Draw a home shape
    Point home_points[1][5];
    home_points[0][0] = Point(200, 200);
    home_points[0][1] = Point(100, 300);
    home_points[0][2] = Point(100, 400);
    home_points[0][3] = Point(300, 400);
    home_points[0][4] = Point(300, 300);

    const Point* ppt[1] = { home_points[0] };
    int npt[] = { 5 };
    fillPoly(image, ppt, npt, 1, Scalar(0, 0, 255));

    // Add text
    putText(image, "OpenCV Drawing", Point(50, 350), FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 255, 255), 2);

    // Display the image
    imshow("Task Image", image);
    waitKey(0);

    return 0;
}