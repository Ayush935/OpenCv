#include<iostream>
#include<opencv2/opencv.hpp>

//Box filtering

int main(int argc, char** argv)
{
    // Load the image
    cv::Mat src = cv::imread("/home/kpit/opencv/samples/data/lena.jpg");

    // Create a destination image
    cv::Mat dst;
    cv::Mat dst1;
    cv::Mat dst2;
    cv::Mat dst3;


    //Display orignal image
    cv::imshow("Display image", src);
   
    // Apply the box filter

    //cv::boxFilter(src, dst, -1, cv::Size(5, 5));

    //normalize = true, border type = BORDER_DEFAULT
    cv::boxFilter(src, dst, -1, cv::Size(5, 5),cv::Point(-1,-1),true,cv::BORDER_ISOLATED);
    
    //blurring effect
    cv::blur(src,dst1,cv::Size(5,5),cv::Point(-1,-1),cv::BORDER_DEFAULT);

    //Guassian filter
    cv::GaussianBlur(src,dst2,cv::Size(5,5),0.0,0,cv::BORDER_DEFAULT);

    //median Blur
    cv::medianBlur(src,dst3,5);

    // Display the filtered image
    cv::imshow("Box Filter", dst);
    cv::imshow("Image Blur", dst1);
    cv::imshow("Image Guassian Blur", dst1);
    cv::imshow("Image Median Blur",dst3);
    cv::waitKey(0);

    return 0;
}