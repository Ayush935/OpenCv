#include <iostream>
#include <opencv2/opencv.hpp>
using namespace cv;
using namespace std;

int main(){
     // Read the image file
Mat image = imread("/home/kpit/opencv/samples/data/lena.jpg",IMREAD_COLOR);

// Convert the image from BGR to YCrCb color space
Mat hist_equalized_image;
cvtColor(image, hist_equalized_image, COLOR_BGR2YCrCb);

// Split the image into 3 channels; Y, Cr, and Cb channels respectively
vector<Mat> vec_channels;
split(hist_equalized_image, vec_channels);

// Equalize the histogram of the Y channel
equalizeHist(vec_channels[0], vec_channels[0]);

// Merge 3 channels to form the color image in YCrCb color space
merge(vec_channels, hist_equalized_image);

// Convert the histogram equalized image from YCrCb to BGR color space
cvtColor(hist_equalized_image, hist_equalized_image, COLOR_YCrCb2BGR);

// Display the original and histogram equalized images
imshow("Original Image", image);
imshow("Histogram Equalized Image", hist_equalized_image);


waitKey(0);

}