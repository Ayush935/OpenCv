
#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
 
using namespace std;
using namespace cv;
 
int main()
{
    Mat src = imread("/home/kpit/opencv/samples/data/opencv-logo.png");
    Mat img = src.clone();
    Mat edges;
    
    //preprocessing
    blur(img, img, Size(3, 3));
    Canny(img, edges, 50, 150);
 
    vector<vector<Point>> contours;
    vector<Vec4i> hierarchy;
 
    // finding contours
    findContours(edges, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE);
    // draw contours
    Mat contour_image = src.clone();
    drawContours(contour_image, contours, -1, Scalar(0, 255, 0), 2);
    imshow(" Contour image ", contour_image); // display contours
 
    // convex hull and bounding rectangles
    Mat conveximage = src.clone();
    Mat rectangle_image = src.clone();
    Mat Rotated_rectangle = src.clone();
    Mat circle_image = src.clone();
    Mat ellipse_image = src.clone();
 
    vector<vector<Point>> hulls(contours.size());
    for (int i = 0; i < contours.size(); i++)
    {
        // convexhull
        convexHull(contours[i], hulls[i]);
 
        // minimum bounding rectangle
        Rect bounding_rect = boundingRect(contours[i]);
        rectangle(rectangle_image, bounding_rect, Scalar(0, 0, 255), 2);
 
        // Rotated rectangel
        RotatedRect rotated_rect = minAreaRect(contours[i]);
        Point2f cornerPoints[4];
        rotated_rect.points(cornerPoints);
        for (int i = 0; i < 4; i++)
        {
            line(Rotated_rectangle, cornerPoints[i], cornerPoints[(i + 1) % 4], Scalar(255, 0, 0), 2);
        }
 
        // minimum enclosing circle
        Point2f centre;
        float radius;
        minEnclosingCircle(contours[i], centre, radius);
        circle(circle_image, centre, radius, Scalar(0, 255, 0), 3);
 
        // minimum area ellipse
        RotatedRect ellipse_instance = fitEllipse(contours[i]);
        ellipse(ellipse_image, ellipse_instance, Scalar(255, 0, 0), 2);
    }
 
    for (size_t i = 0; i < contours.size(); i++)
    {
        cv::Moments moments = cv::moments(contours[i]);
 
        std::cout << "Contour " << i << " moments:" << std::endl;
        // Spatial Moments
        std::cout << "  Spatial Moments:" << std::endl;
        std::cout << "    m00: " << moments.m00 << std::endl;
        std::cout << "    m10: " << moments.m10 << std::endl;
        std::cout << "    m01: " << moments.m01 << std::endl;
    }
 
    for (size_t i = 0; i < contours.size(); i++) //loop to display the moments of the image
    {
        cv::Moments moments = cv::moments(contours[i]);
        std::cout << "Contour Area of contour  " << i << " is " << moments.m00 << endl;
    }
 
    for (size_t i = 0; i < contours.size(); i++)  //to display the perimeter of the contours
    {
        double perimeter = cv::arcLength(contours[i], true); // true indicates the contour is closed
        std::cout << "Contour " << i << " perimeter: " << perimeter << std::endl;
    }
 
    drawContours(conveximage, hulls, -1, Scalar(255, 0, 0), 2);
    imshow("Convex Hull image", conveximage);
    imshow("Rectangel image", rectangle_image);
    imshow("Rotated rectangel image", Rotated_rectangle);
    imshow("Circle image", circle_image);
    imshow("Ellipse image ", ellipse_image);
 
    //saving all the output images
    imwrite("219363_3.jpg", contour_image);
    imwrite("219363_4a.jpg", conveximage);
    imwrite("219363_4b.jpg", rectangle_image);
    imwrite("219363_4c.jpg", Rotated_rectangle);
    imwrite("219363_4d.jpg", circle_image);
    imwrite("219363_4e.jpg", ellipse_image);
 
    waitKey(0);
 
    return 0;
}