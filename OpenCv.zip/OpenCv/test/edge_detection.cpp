// #include <iostream>
// #include <opencv2/opencv.hpp>
// #include <vector>
 
// using namespace std;
// using namespace cv;
 
// int main()
// {
 
//     cv::VideoCapture cap(0);
//     Mat frame;
//     while (true)
//     {
//         cap.read(frame);
//         Mat EdgeImg;
//         Canny(frame, EdgeImg, 100, 200);
//         imshow("Original WebCam", frame);
//         imshow("Edge WebCam", EdgeImg);
//         if (waitKey(1) == 'q')
//         {
//             break;
//         }
//     }
//     cap.release();
//     destroyAllWindows();
 
//     return 0;
// }


#include <opencv2/opencv.hpp>

using namespace cv;

// Function to apply Prewitt edge detection
void Kernel_Prewitt(Mat& src, Mat& dst, int direction) {
    Mat kernelx = (Mat_<char>(3, 3) << -1, 0, 1, -1, 0, 1, -1, 0, 1);
    Mat kernely = (Mat_<char>(3, 3) << -1, -1, -1, 0, 0, 0, 1, 1, 1);

    if (direction == 0) {
        filter2D(src, dst, src.depth(), kernelx);
    } else if (direction == 1) {
        filter2D(src, dst, src.depth(), kernely);
    } else if (direction == 2) {
        Mat temp1, temp2;
        filter2D(src, temp1, src.depth(), kernelx);
        filter2D(src, temp2, src.depth(), kernely);
        addWeighted(temp1, 0.5, temp2, 0.5, 0, dst);
    }
}

// Function to apply Roberts edge detection
void Kernel_Roberts(Mat& src, Mat& dst, int direction) {
    Mat kernelx = (Mat_<char>(2, 2) << 0, 1, -1, 0);
    Mat kernely = (Mat_<char>(2, 2) << 1, 0, 0, -1);

    if (direction == 0) {
        filter2D(src, dst, src.depth(), kernelx);
    } else if (direction == 1) {
        filter2D(src, dst, src.depth(), kernely);
    } else if (direction == 2) {
        Mat temp1, temp2;
        filter2D(src, temp1, src.depth(), kernelx);
        filter2D(src, temp2, src.depth(), kernely);
        addWeighted(temp1, 0.5, temp2, 0.5, 0, dst);
    }
}

int main() {
    Mat image = imread("/home/kpit/opencv/samples/data/lena.jpg", IMREAD_COLOR); // Load image in grayscale

    if (image.empty()) {
        std::cerr << "Error: Image not found or unable to load." << std::endl;
        return -1;
    }

    // Sobel Edge Detection
    Mat sobelx, sobely, sobelxy;
    Sobel(image, sobelx, CV_64F, 1, 0, 3); // Horizontal edges
    Sobel(image, sobely, CV_64F, 0, 1, 3); // Vertical edges
    Sobel(image, sobelxy, CV_64F, 1, 1, 3); // Both horizontal and vertical edges
    imshow("Sobel Edges", sobelxy);

    // Prewitt Edge Detection
    Mat prewittx, prewitty, prewittxy;
    Kernel_Prewitt(image, prewittx, 0); // Horizontal edges
    Kernel_Prewitt(image, prewitty, 1); // Vertical edges
    Kernel_Prewitt(image, prewittxy, 2); // Both horizontal and vertical edges
    imshow("Prewitt Edges", prewittxy);

    // Roberts Edge Detection
    Mat robertsx, robertsy, robertsxy;
    Kernel_Roberts(image, robertsx, 0); // Diagonal edges (top-left to bottom-right)
    Kernel_Roberts(image, robertsy, 1); // Diagonal edges (top-right to bottom-left)
    Kernel_Roberts(image, robertsxy, 2); // Both diagonal edges
    imshow("Roberts Edges", robertsxy);

    // Canny Edge Detection
    Mat edges;
    Canny(image, edges, 100, 200); // Apply Canny edge detection with threshold values
    imshow("Canny Edges", edges);

    waitKey(0);
    destroyAllWindows();

    return 0;
}