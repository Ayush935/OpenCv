#include <opencv2/opencv.hpp>

int main() {
    cv::Mat image = cv::imread("/home/kpit/opencv/samples/data/lena.jpg");
    
    // Define 3 points on input image and corresponding points on output
    std::vector<cv::Point2f> pts1 = {{50,50}, {200,50}, {50,200}};
    std::vector<cv::Point2f> pts2 = {{10,100}, {200,50}, {100,250}};
    
    // Compute affine transformation matrix
    cv::Mat M = cv::getAffineTransform(pts1, pts2);
    
    // Apply affine transformation to image
    cv::Mat output;
    cv::warpAffine(image, output, M, image.size());
    
    cv::imshow("Output", output);
    cv::waitKey(0);
    return 0;
}