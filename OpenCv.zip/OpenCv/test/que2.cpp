// #include <opencv2/opencv.hpp>

// int main() {
//     // Load the image
//     cv::Mat image = cv::imread("/home/kpit/opencv/samples/data/chessboard.png");

   
//     cv::Mat gray;
//     cv::cvtColor(image, gray, cv::COLOR_BGR2GRAY);

//     cv::Mat edges;
//     cv::Canny(gray, edges, 50, 200);

   
//     std::vector<cv::Vec2f> lines;
//     cv::HoughLines(edges, lines, 1, CV_PI/180, 200);

//     cv::Mat dst;
//     cvtColor(edges, dst, cv::COLOR_GRAY2BGR);
//     for( size_t i = 0; i < lines.size(); i++ )
//     {
//         float rho = lines[i][0], theta = lines[i][1];
//         cv::Point pt1, pt2;
//         double a = cos(theta), b = sin(theta);
//         double x0 = a*rho, y0 = b*rho;
//         pt1.x = cvRound(x0 + 1000*(-b));
//         pt1.y = cvRound(y0 + 1000*(a));
//         pt2.x = cvRound(x0 - 1000*(-b));
//         pt2.y = cvRound(y0 - 1000*(a));
//         cv::line(image, pt1, pt2, cv::Scalar(0, 0, 255), 2, cv::LINE_AA);
//     }

//     imshow("Detected Lines (in red) - Standard Hough Line Transform", image);
//     cv::imshow("Hough Lines", image);
//     cv::imwrite("219363_HL1.jpg",image);
//     cv::waitKey(0);
//     cv::destroyAllWindows();

//     return 0;
// }

#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main()
{
    Mat src = imread("/home/kpit/opencv/samples/data/chessboard.png", IMREAD_UNCHANGED);
    imshow("Original image", src);

    Mat dst, cdstP, cdst;

    Canny(src, dst, 50, 200);

    cvtColor(dst, cdst, COLOR_GRAY2BGR);
    cdstP = cdst.clone();
  
    vector<Vec2f> lines;                               
    HoughLines(dst, lines, 1, CV_PI / 180, 200); 
    
    for (size_t i = 0; i < lines.size(); i++)
    {
        float rho = lines[i][0], theta = lines[i][1];
        Point pt1, pt2;
        double a = cos(theta), b = sin(theta);
        double x0 = a * rho, y0 = b * rho;
        pt1.x = cvRound(x0 + 1000 * (-b));
        pt1.y = cvRound(y0 + 1000 * (a));
        pt2.x = cvRound(x0 - 1000 * (-b));
        pt2.y = cvRound(y0 - 1000 * (a));
        line(cdst, pt1, pt2, Scalar(255, 0, 0), 2, LINE_AA);
    }

    imshow("hough", cdst);
    imwrite("219363_HL1.jpg",cdst);

    waitKey(0);
    return 0;
}

