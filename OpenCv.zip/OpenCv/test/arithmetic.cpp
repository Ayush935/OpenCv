#include <iostream>
#include <opencv2/opencv.hpp>

int main()
{
    std::string path = "/home/kpit/opencv/samples/data/lena.jpg";
    cv::Mat img = cv::imread(path, cv::IMREAD_COLOR);

    cv::Mat new_img = cv::imread("/home/kpit/opencv/samples/data/fruits.jpg", cv::IMREAD_COLOR);
    cv::Mat new_img1, new_img2, dest;
    cv::resize(img, new_img1, cv::Size(300, 300), cv::INTER_LINEAR);
    cv::resize(new_img, new_img2, cv::Size(300, 300), cv::INTER_LINEAR);
    std::cout << "Enter Brightness " << std::endl;
    float brightness;
    std::cin >> brightness;
    std::cout << "Enter Contrast " << std::endl;
    float contrast;
    std::cin>>contrast;
    // cv::addWeighted(new_img1, contrast, new_img2, brightness,0.0 ,dest);
    // cv::multiply(new_img1,new_img2,dest);
    // cv::divide(new_img1,new_img2,dest);
    // cv::subtract(new_img1,new_img2,dest);
    // cv::add(new_img1,new_img2,dest);
    // cv::bitwise_xor(new_img1,new_img2,dest);
    // cv::bitwise_and(new_img1,new_img2,dest);
    // cv::bitwise_or(new_img1,new_img2,dest);
    cv::bitwise_not(new_img1,dest);
    cv::imshow("img",dest);
    cv::waitKey(0);
}