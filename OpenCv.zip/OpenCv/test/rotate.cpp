#include <opencv2/opencv.hpp>

int main() {
    cv::Mat image = cv::imread("/home/kpit/opencv/samples/data/fruits.jpg");
    cv::imshow("Image", image);
    // Rotate the image by 45 degrees clockwise
    cv::Point2f center(image.cols / 2.0, image.rows / 2.0);
    cv::Mat rotation_matrix = cv::getRotationMatrix2D(center, 45, 1.0);
    cv::Mat rotated_image;
    cv::warpAffine(image, rotated_image, rotation_matrix, image.size());

    cv::imshow("Rotated Image", rotated_image);
    cv::imwrite("rotated_image.jpg", rotated_image);

    cv::waitKey(0);
    return 0;
}