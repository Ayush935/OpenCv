// #include <iostream>
// #include <opencv2/opencv.hpp>

// using namespace std;
// using namespace cv;


// int main(){
//       // Read the grayscale image file
//     Mat image = imread("/home/kpit/opencv/samples/data/lena.jpg", IMREAD_GRAYSCALE);

//     // Create a window for the original image
//     namedWindow("Original Image", WINDOW_AUTOSIZE);
//     imshow("Original Image", image);

//     // Equalize the histogram of the image
//     Mat equalized_image;
//     equalizeHist(image, equalized_image);

//     // Create a window for the equalized image
//     namedWindow("Equalized Image", WINDOW_AUTOSIZE);
//     imshow("Equalized Image", equalized_image);
//     waitKey(0);
// }


#include <opencv2/opencv.hpp>
#include <iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
 
using namespace cv;
using namespace std;
 
Mat equalizeHistogram(const Mat &inputImage)
{
    // Check if the image is empty
    if (inputImage.empty())
    {
        cout << "Input image is empty" << endl;
        return Mat();
    }
 
    // Perform histogram equalization
    Mat equalizedImage;
    equalizeHist(inputImage, equalizedImage);
 
    return equalizedImage;
}
 
void plotHistogram(const Mat &image, const string &windowName)
{
    // Calculate histogram
    Mat hist;
    int histSize = 256;
    float range[] = {0, 256};
    const float *histRange = {range};
    calcHist(&image, 1, nullptr, Mat(), hist, 1, &histSize, &histRange);
 
    // Normalize histogram
    int hist_w = 512;
    int hist_h = 400;
    int bin_w = cvRound((double)hist_w / histSize);
    Mat histImage(hist_h, hist_w, CV_8UC3, Scalar(255, 255, 255));
    normalize(hist, hist, 0, histImage.rows, NORM_MINMAX, -1, Mat());
 
    // Draw histogram
    for (int i = 1; i < histSize; i++)
    {
        line(histImage, Point(bin_w * (i - 1), hist_h - cvRound(hist.at<float>(i - 1))),
             Point(bin_w * i, hist_h - cvRound(hist.at<float>(i))),
             Scalar(0, 0, 0), 2, 8, 0);
    }
 
    // Show histogram
    namedWindow(windowName, WINDOW_AUTOSIZE);
    imshow(windowName, histImage);
}
 
int main()
{
    // Load image
    Mat image = imread("/home/kpit/opencv/samples/data/lena.jpg", IMREAD_GRAYSCALE); // Load grayscale image
 
    // Check if the image is loaded successfully
    if (image.empty())
    {
        cout << "Could not open or find the image" << endl;
        return -1;
    }
 
    // Perform histogram equalization
    Mat equalizedImage = equalizeHistogram(image);
 
    // Display original and equalized images
    namedWindow("Original Image", WINDOW_AUTOSIZE);
    imshow("Original Image", image);
 
    namedWindow("Equalized Image", WINDOW_AUTOSIZE);
    imshow("Equalized Image", equalizedImage);
 
    // Plot histograms
    plotHistogram(image, "Original Histogram");
    plotHistogram(equalizedImage, "Equalized Histogram");
 
    waitKey(0);
 
    return 0;
}
 