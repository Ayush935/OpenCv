#include <opencv2/opencv.hpp>

int main()
{
    // Load the input image
    cv::Mat src = cv::imread("/home/kpit/opencv/samples/data/lena.jpg");

    // Create the output image
    cv::Mat dst;
    
    // Display Orignal Image
    cv::imshow("Orignal Image", src);

    // Define the kernel
    cv::Mat kernel = (cv::Mat_<float>(3,3) << 
                      1/9.0, 7/9.0, 1/9.0,
                      4/9.0, 1/9.0, 1/9.0,
                      1/9.0, 9/9.0, 1/9.0);

    // Apply the filter2D function
    cv::filter2D(src, dst, -1, kernel, cv::Point(-1,-1), 0, cv::BORDER_DEFAULT);

    // Display the output image
    cv::imshow("Filter2D Image", dst);
    cv::waitKey(0);

    return 0;
}