
#include <opencv2/opencv.hpp>
#include <iostream>
 
using namespace cv;
using namespace std;
 
 
 
string detectTrafficLight(const Mat& src) {
    Mat hsv;
    cvtColor(src, hsv, COLOR_BGR2HSV);
 
    // HSV valuesm
    Scalar lower_red = Scalar(160, 100, 100);
    Scalar upper_red = Scalar(179, 255, 255);
    Scalar lower_yellow = Scalar(22, 100, 100);
    Scalar upper_yellow = Scalar(38, 255, 255);
    Scalar lower_green = Scalar(38, 70, 50);
    Scalar upper_green = Scalar(75, 255, 255);
 
    // Threshold the HSV image to get only red, yellow, and green colors
    Mat mask_red, mask_yellow, mask_green;
    inRange(hsv, lower_red, upper_red, mask_red);
    inRange(hsv, lower_yellow, upper_yellow, mask_yellow);
    inRange(hsv, lower_green, upper_green, mask_green);
 
    // Count the number of non-zero pixels in each mask
    int red_count = countNonZero(mask_red);
    int yellow_count = countNonZero(mask_yellow);
    int green_count = countNonZero(mask_green);
 
 
    cout<<red_count<<" "<<yellow_count<<" "<<green_count;
 
    // Determine the traffic light color based on the highest count
    if (red_count > yellow_count && red_count > green_count) {
        return "Red";
    } else if (yellow_count > red_count && yellow_count > green_count) {
        return "Yellow";
    } else  {
        return "Green";
    }
}
 
int main()
{
    Mat src = imread("/home/kpit/Downloads/traffic_light1.png");
    Mat gray;
    cvtColor(src, gray, COLOR_BGR2GRAY);
    medianBlur(gray, gray, 5);
    vector<Vec3f> circles;
    HoughCircles(gray, circles, HOUGH_GRADIENT, 1, gray.rows / 16, 100, 30, 1, 30  );
 
    // Create a mask for the circles
    Mat mask = Mat::zeros(src.size(), CV_8UC1);
    for (size_t i = 0; i < circles.size(); i++)
    {
        Vec3i c = circles[i];
        Point center = Point(c[0], c[1]);
        int radius = c[2];
        circle(mask, center, radius, Scalar(255), -1); // Fill circle area with white
    }
 
    // Set the areas outside the circles to black
    Mat result;
    src.copyTo(result, mask);
 
 
    string color = detectTrafficLight(result);
 
    // Display the result
    cout << "Traffic light color: " << color << endl;
 
 
 
    return EXIT_SUCCESS;
}
 