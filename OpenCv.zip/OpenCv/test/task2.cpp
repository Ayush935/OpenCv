// #include <opencv2/opencv.hpp>

// using namespace cv;

// int main() {
//     // Read the image
//     Mat img = imread("/home/kpit/opencv/samples/data/opencv-logo.png", IMREAD_COLOR); // Read the image in color

//     // Add a black color border
//     int borderSize = 20;
//     // Mat constant = Mat::zeros(img.rows + 2 * borderSize, img.cols + 2 * borderSize, img.type());
//     // img.copyTo(constant(Rect(borderSize, borderSize, img.cols, img.rows)));

//     // // Add OpenCV and Logo texts to the image
//     // putText(constant, "OpenCV", Point(50, 50), FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 255, 255), 2); // Add OpenCV text
//     // putText(constant, "Logo", Point(50, 100), FONT_HERSHEY_SIMPLEX, 1, Scalar(255, 255, 255), 2); // Add Logo text

//     // // Display the image
//     // imshow("OpenCV Logo", constant);

//     // // Save the modified image
//     // imwrite("219363.png", constant); // Save the image with text
//     imshow("img",img);
//     waitKey(0);
//     destroyAllWindows();

//     return 0;
// }


#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
 
using namespace std;
using namespace cv;
 
int main()
{
    Mat original = imread("/home/kpit/opencv/samples/data/opencv-logo.png",IMREAD_UNCHANGED);
 
    Mat img(original.size(),CV_8UC3);
 
    vector<Mat> channels;
    split(original,channels);
 
    for(int i=0;i<original.rows;i++)
    {
    for(int j=0;j<original.cols;j++)
    {
        float alpha=channels[3].at<uchar>(i,j)/255.0f;
        img.at<Vec3b>(i,j)[0]=channels[0].at<uchar>(i,j)*alpha +(1-alpha)*255;
        img.at<Vec3b>(i,j)[1]=channels[1].at<uchar>(i,j)*alpha +(1-alpha)*255;
        img.at<Vec3b>(i,j)[2]=channels[2].at<uchar>(i,j)*alpha +(1-alpha)*255;
    }
 
    }
 
    Mat imgo=img.clone();
 
    int top=0.05*(img.rows);
    int left=0.05*(img.cols);
    int bottom=top;
    int right=left;
 
    copyMakeBorder(img,img,top,bottom,left,right,BORDER_CONSTANT,Scalar(0,0,0));
 
    imshow("Original image ",imgo);
    imshow("Bordered image ",img);
    // imwrite("219596.jpg",img);
 
    waitKey(0);
 
 
    return 0;
}
