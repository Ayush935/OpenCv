
#include <opencv2/opencv.hpp>
#include <iostream>
#include <cmath>
 
using namespace cv;
using namespace std;
 
void detectShapes(Mat &image)
{
    Mat gray, blurred, thresholded;
 
    cvtColor(image, gray, COLOR_BGR2GRAY);
 
    GaussianBlur(gray, blurred, Size(3, 3), 1);
 
    adaptiveThreshold(blurred, thresholded, 255, ADAPTIVE_THRESH_GAUSSIAN_C, THRESH_BINARY_INV, 11, 2);
    
    vector<vector<Point>> contours;
    findContours(thresholded, contours, RETR_EXTERNAL, CHAIN_APPROX_NONE);
 
    for (const auto &contour : contours)
    {
        vector<Point> approx;
        approxPolyDP(contour, approx, arcLength(contour, true) * 0.012, true);
 
        string shape;
        int vertices = approx.size();
 
        if (vertices == 3)
        {
            shape = "Triangle";
        }
        else if (vertices == 4)
        {
            Rect rect = boundingRect(approx);
            float aspectRatio = (float)rect.width / rect.height;
            shape = (aspectRatio >= 1 && aspectRatio <= 1.02) ? "Square" : "Rectangle";
        }
        else if (vertices == 5)
        {
            shape = "Pentagon";
        }
        else if (vertices == 6)
        {
            shape = "Hexagon";
        }
        else if (vertices == 8)
        {
            shape = "Octagon";
        }
        else
        {
            RotatedRect ellipse = fitEllipse(contour);
            float aspectRatio = (float)ellipse.size.width / ellipse.size.height;
            shape = (aspectRatio >= 0.98 && aspectRatio <= 1.25) ? "Circle" : "Ellipse";
        }
 
        drawContours(image, contours, -1, Scalar(0, 255, 0), 2);
        putText(image, shape, approx[0], FONT_HERSHEY_SIMPLEX, 0.5, Scalar(255, 255, 255), 2);
    }
}
 
int main()
{
    Mat image = imread("/home/kpit/Downloads/basicShapes.png");
 
    if (image.empty())
    {
        cout << "Could not open or find the image!" << endl;
        return -1;
    }
 
    detectShapes(image);
 
    imshow("Detected Shapes", image);
    waitKey(0);
 
    return 0;
}