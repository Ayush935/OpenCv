#include <opencv2/opencv.hpp>

int main() {
    // Load the input image
    cv::Mat image = cv::imread("/home/kpit/opencv/samples/data/lena.jpg");
    cv::imshow("Display img",image);
    // Define the source points (corners of the object in the image)
    std::vector<cv::Point2f> src_points = {
        {0.0f, 0.0f},
        {static_cast<float>(image.cols), 0.0f},
        {static_cast<float>(image.cols), static_cast<float>(image.rows)},
        {0.0f, static_cast<float>(image.rows)}
    };

    // Define the destination points (desired output image size)
    std::vector<cv::Point2f> dst_points = {
        {0.0f, 0.0f},
        {300.0f, 0.0f},
        {30.0f, 40.0f},
        {0.0f, 400.0f}
    };

    // Calculate the perspective transformation matrix
    cv::Mat transformation_matrix = cv::getPerspectiveTransform(src_points, dst_points);

    // Apply the perspective transformation
    cv::Mat output_image;
    cv::warpPerspective(image, output_image, transformation_matrix, cv::Size(300, 400));

    // Display the output image
    cv::imshow("Output Image", output_image);
    cv::waitKey(0);
    cv::destroyAllWindows();

    return 0;
}