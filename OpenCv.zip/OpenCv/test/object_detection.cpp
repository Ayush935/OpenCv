
// #include <opencv2/opencv.hpp>
// #include <iostream>
 
// int main() {
//     // Open the default camera
//     cv::VideoCapture cap(0); // 0 for the default camera
//     if (!cap.isOpened()) {
//         std::cerr << "Error opening video capture\n";
//         return -1;
//     }
 
//     cv::Mat frame, gray, blurred, edged;
//     while (cap.read(frame)) {
//         if (frame.empty()) {
//             std::cerr << "No captured frame -- Break!\n";
//             break;
//         }
 
//         // Convert to grayscale
//         cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
 
//         // Blur the image to reduce noise
//         cv::GaussianBlur(gray, blurred, cv::Size(5, 5), 0);
 
//         // Edge detection using Canny
//         cv::Canny(blurred, edged, 50, 150);
 
//         // Find contours
//         std::vector<std::vector<cv::Point>> contours;
//         std::vector<cv::Vec4i> hierarchy;
//         cv::findContours(edged, contours, hierarchy, cv::RETR_TREE, cv::CHAIN_APPROX_SIMPLE);
 
//         // Draw contours
//         cv::Mat contourOutput = frame.clone();
//         for (size_t idx = 0; idx < contours.size(); idx++) {
//             cv::drawContours(contourOutput, contours, static_cast<int>(idx), cv::Scalar(0, 255, 0), 2);
//         }
 
//         // Show the result
//         cv::imshow("Contours", contourOutput);
 
//         // Exit if ESC key is pressed
//         if (cv::waitKey(10) == 27) {
//             break;
//         }
//     }
 
//     return 0;
// }
 

#include <opencv2/opencv.hpp>
#include <iostream>
 
int main() {
    // Read the image file
    std::string imagePath = "/home/kpit/opencv/samples/data/cards.png"; // Replace with your image path
    cv::Mat image = cv::imread(imagePath, cv::IMREAD_COLOR);
 
    // Check if image is loaded successfully
    if (image.empty()) {
        std::cerr << "Error loading image\n";
        return -1;
    }
 
    cv::Mat gray, blurred, edged;
 
    // Convert to grayscale
    cv::cvtColor(image, gray, cv::COLOR_BGR2GRAY);
 
    // Blur the image to reduce noise
    cv::GaussianBlur(gray, blurred, cv::Size(5, 5), 0);
 
    // Edge detection using Canny
    cv::Canny(blurred, edged, 50, 150);
 
    // Find contours
    std::vector<std::vector<cv::Point>> contours;
    std::vector<cv::Vec4i> hierarchy;
    cv::findContours(edged, contours, hierarchy, cv::RETR_TREE, cv::CHAIN_APPROX_SIMPLE);
 
    // Draw contours
    cv::Mat contourOutput = image.clone();
    for (size_t idx = 0; idx < contours.size(); idx++) {
        cv::drawContours(contourOutput, contours, static_cast<int>(idx), cv::Scalar(0, 255, 0), 2);
    }
 
    // Show the result
    cv::imshow("Original Image", image);
    cv::imshow("Contours", contourOutput);
 
    // Wait for a key press indefinitely
    cv::waitKey(0);
 
    return 0;
}
 

