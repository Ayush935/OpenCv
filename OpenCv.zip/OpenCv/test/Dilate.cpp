#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

int main() {
    // Read the input image
    cv::Mat src = cv::imread("/home/kpit/opencv/samples/data/LinuxLogo.jpg", cv::IMREAD_GRAYSCALE);
    
    // Create a structuring element (kernel)
    int dilation_size = 5;
    cv::Mat element = cv::getStructuringElement(cv::MORPH_RECT,
                                               cv::Size(dilation_size + 1, dilation_size+1),
                                               cv::Point(dilation_size, dilation_size));
    
    // Apply dilation
    cv::Mat dilated;
    cv::dilate(src, dilated, element, cv::Point(-1,-1), 1);

    //Display the orignal image
    cv::imshow("Orignal Image", src);
    
    // Display the dilated image
    cv::imshow("Dilated Image", dilated);
    cv::waitKey(0);
    
    return 0;
}