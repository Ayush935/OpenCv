#include <opencv2/opencv.hpp>
#include <iostream>

// void gammaCorrection(const cv::Mat& src, cv::Mat& dst, float gamma) {
//     CV_Assert(src.depth() == CV_8U); // only support 8-bit images

//     float invGamma = 1.0f / gamma;
//     cv::Mat table(1, 256, CV_8U);
//     uchar* p = table.ptr();
//     for (int i = 0; i < 256; ++i) {
//         p[i] = static_cast<uchar>(std::pow(i / 255.0f, invGamma) * 255);
//     }

//     cv::LUT(src, table, dst);

// }

int main()
{
    cv::Mat image = cv::imread("/home/kpit/opencv/samples/data/lena.jpg");
    cv::imshow("Original Image", image);
    cv::Mat gammaImage = image;
    float invGamma = 1.0f / 2.2f;

    for (int i = 0; i < image.rows; i++)
    {
        for (int j = 0; j < image.cols; j++)
        {
            for (int c = 0; c < image.channels(); c++)
            {
                gammaImage.at<cv::Vec3b>(i, j)[c] =
                    cv::saturate_cast<uchar>(std::pow((image.at<cv::Vec3b>(i, j)[c] / 255.0f), invGamma) * 255);
            }
        }
    }

    cv::imshow("Gamma Corrected Image", gammaImage);
    cv::waitKey(0);
    cv::destroyAllWindows();

    return 0;
}