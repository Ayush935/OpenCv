
#include <opencv2/opencv.hpp>
#include <iostream>
 
using namespace cv;
using namespace std;
 
int main(int argc, char** argv) {
    // Read the image file
    Mat img = imread("/home/kpit/Downloads/traffic_light1.png");
    if (img.empty()) {
        cout << "Could not open or find the image!" << endl;
        return -1;
    }
 
    // Convert image to HSV color space
    Mat hsv;
    cvtColor(img, hsv, COLOR_BGR2HSV);
    blur(hsv,hsv,Size(5,5));
 
    // Define the color ranges for red, yellow, and green in HSV space
    Scalar redLower1 = Scalar(0, 100, 100), redUpper1 = Scalar(10, 255, 255);
    Scalar redLower2 = Scalar(160, 100, 100), redUpper2 = Scalar(179, 255, 255);
    Scalar yellowLower = Scalar(20, 100, 100), yellowUpper = Scalar(30, 255, 255);
    Scalar greenLower = Scalar(40, 100, 100), greenUpper = Scalar(90, 255, 255);
 
    // Create masks for red, yellow, and green colors
    Mat redMask1, redMask2, redMask, yellowMask, greenMask;
    inRange(hsv, redLower1, redUpper1, redMask1);
    inRange(hsv, redLower2, redUpper2, redMask2);
    inRange(hsv, yellowLower, yellowUpper, yellowMask);
    inRange(hsv, greenLower, greenUpper, greenMask);
    bitwise_or(redMask1, redMask2, redMask);
 
    // Apply morphological operations to clean up the masks
    Mat kernel = getStructuringElement(MORPH_ELLIPSE, Size(5, 5));
    morphologyEx(redMask, redMask, MORPH_CLOSE, kernel);
    morphologyEx(yellowMask, yellowMask, MORPH_CLOSE, kernel);
    morphologyEx(greenMask, greenMask, MORPH_CLOSE, kernel);
 
    // Detect contours in the masks
    vector<vector<Point>> redContours, yellowContours, greenContours;
    findContours(redMask, redContours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
    findContours(yellowMask, yellowContours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
    findContours(greenMask, greenContours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
 
    // Function to process contours and draw results
    auto processContours = [&](const vector<vector<Point>>& contours, const Scalar& color, const string& colorName) {
        for (const auto& contour : contours) {
            Rect boundingBox = boundingRect(contour);
            Point center(boundingBox.x + boundingBox.width / 2, boundingBox.y + boundingBox.height / 2);
            int radius = boundingBox.width / 2;
 
            // Ensure the bounding box is roughly square and has a minimum size
            if (abs(boundingBox.width - boundingBox.height) < 10 && boundingBox.width > 10) {
                // Draw the circle and label on the original image
                circle(img, center, radius, color, 2);
                putText(img, colorName, Point(center.x - radius, center.y - radius - 10), FONT_HERSHEY_SIMPLEX, 0.6, color, 2);
            }
        }
    };
    processContours(redContours, Scalar(0, 0, 255), "Red");
    processContours(yellowContours, Scalar(0, 255, 255), "Yellow");
    processContours(greenContours, Scalar(0, 255, 0), "Green");
 
    // Save the result
    imwrite("output_1.jpeg", img);
    return 0;
}
 